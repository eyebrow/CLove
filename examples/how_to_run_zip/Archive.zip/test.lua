test = {}
test.__index = test 

function test.create()
	local self = {}
	self.x = 200
	self.y = 20
	return setmetatable(self,test)
end

function test:draw()
	love.graphics.print("HELLOOO",self.x,self.y)
end